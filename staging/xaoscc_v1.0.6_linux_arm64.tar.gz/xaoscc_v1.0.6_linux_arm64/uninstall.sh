#!/usr/bin/env bash
# Removes the panel and nothing else: sites, databases, mail and nginx keep running.
# With --purge the panel's own config, keys and database are deleted too.
set -euo pipefail

[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

purge=no
[[ "${1:-}" == "--purge" ]] && purge=yes

systemctl disable --now xaosccd.service xaoscc-agent.service 2>/dev/null || true
rm -f /etc/systemd/system/xaosccd.service /etc/systemd/system/xaoscc-agent.service
# The webmail is the panel's program; Stalwart and the mail in it stay.
systemctl disable --now xaoscc-webmail.service 2>/dev/null || true
rm -f /etc/systemd/system/xaoscc-webmail.service
# The firewall of web requests (ADR-048) is the panel's program too. Sites behind it keep
# working without it: nginx serves them directly when the service does not answer.
systemctl disable --now xaoscc-waf.service 2>/dev/null || true
rm -f /etc/systemd/system/xaoscc-waf.service
# The sockets Adminer reached the databases by lead nowhere without the panel. The
# adminer stack is a Docker stack like the others and stays with them.
systemctl disable --now xaoscc-adminer-mysql.socket xaoscc-adminer-pgsql.socket \
  xaoscc-adminer-mysql.service xaoscc-adminer-pgsql.service 2>/dev/null || true
rm -f /etc/systemd/system/xaoscc-adminer-*.socket /etc/systemd/system/xaoscc-adminer-*.service
systemctl daemon-reload

rm -f /etc/fail2ban/jail.d/xaoscc.conf /etc/fail2ban/filter.d/xaoscc.conf
systemctl reload fail2ban 2>/dev/null || true
rm -f /etc/logrotate.d/xaoscc-sites

rm -f /usr/local/bin/xaosccd /usr/local/bin/xaoscc-agent /usr/local/bin/xaoscc /usr/local/bin/xaoscc-webmail

if [[ $purge == yes ]]; then
  # Certificates live in /etc/xaoscc/certs and nginx still points at them, so the sites' own
  # nginx files, system users and /var/www are left for the administrator to decide on.
  if compgen -G '/etc/nginx/sites-enabled/xaoscc-*.conf' >/dev/null; then
    echo "Sites created by the panel are still enabled in nginx and use certificates from /etc/xaoscc/certs." >&2
    echo "Remove the sites first, or delete /etc/nginx/sites-enabled/xaoscc-*.conf by hand, then purge." >&2
    exit 1
  fi
  # No site is left to use what the sites shared: the limits, the log formats and the ban.
  rm -f /etc/nginx/conf.d/xaoscc-guard.conf /etc/nginx/conf.d/xaoscc-waf.conf /etc/tmpfiles.d/xaoscc-waf.conf
  ! systemctl is-active --quiet nginx.service || ! nginx -t 2>/dev/null || systemctl reload nginx.service
  rm -f /etc/fail2ban/jail.d/xaoscc-sites.conf /etc/fail2ban/filter.d/xaoscc-sites.conf
  systemctl reload fail2ban 2>/dev/null || true
  rm -f /etc/ssh/sshd_config.d/60-xaoscc-sftp.conf
  ! systemctl is-active --quiet ssh.service || systemctl reload ssh.service
  rm -rf /etc/xaoscc /var/lib/xaoscc /var/log/xaoscc /var/lib/xaoscc-acme /var/lib/xaoscc-agent /etc/ssh/xaoscc
  rm -rf /etc/xaoscc-webmail /var/lib/xaoscc-webmail /etc/xaoscc-waf /run/xaoscc-waf /run/xaoscc-nginx
  userdel xaoscc 2>/dev/null || true
  userdel xaoscc-webmail 2>/dev/null || true
  userdel xaoscc-waf 2>/dev/null || true
  echo "xaosControl removed together with its config, keys and database."
  echo "Site files in /var/www, their logs in /var/log/xaoscc-sites and archives in /var/backups/xaoscc were kept."
else
  echo "xaosControl removed. Config and database are kept in /etc/xaoscc and /var/lib/xaoscc."
  echo "Sites keep working: their nginx files, certificates, SFTP keys and the sshd rules stay in place."
  echo "So does their protection: /etc/nginx/conf.d/xaoscc-guard.conf and the fail2ban jail xaoscc-sites."
  echo "Run again with --purge to delete the panel's own data."
fi
echo "Firewall rules were left as they are; review them with: ufw status numbered"
